/* global React */
const { useState, useEffect } = React;

// ============ Shared data ============
window.DATA = {
  stats: [
    { num: '32', plus: '+', label: 'Dosen Aktif' },
    { num: '147', plus: '+', label: 'Prestasi Mahasiswa' },
    { num: '486', plus: '+', label: 'Mahasiswa Aktif' },
    { num: '12', plus: '+', label: 'Laboratorium & Fasilitas' },
  ],

  dosen: [
    { name: 'Dr. Ir. Ahmad Firdaus, M.Kom.', role: 'Ketua Program Studi', nidn: 'NIDN 0812098701', exp: 'Software Engineering' },
    { name: 'Dr. Sri Wahyuni, S.Kom., M.T.', role: 'Sekretaris Prodi', nidn: 'NIDN 0823079102', exp: 'Data Science' },
    { name: 'Budi Santoso, S.Kom., M.Cs.', role: 'Dosen Tetap', nidn: 'NIDN 0814058803', exp: 'Mobile Development' },
    { name: 'Nurul Hidayah, S.T., M.Kom.', role: 'Dosen Tetap', nidn: 'NIDN 0902098904', exp: 'UI/UX Design' },
    { name: 'Rizky Pratama, S.Kom., M.T.', role: 'Dosen Tetap', nidn: 'NIDN 0707098605', exp: 'Cloud Computing' },
    { name: 'Indah Permatasari, M.Kom.', role: 'Dosen Tetap', nidn: 'NIDN 0518059006', exp: 'Cyber Security' },
    { name: 'Ir. Agus Salim, M.T.', role: 'Dosen Tetap', nidn: 'NIDN 0611048707', exp: 'IoT & Embedded' },
    { name: 'Siti Maryam, S.Kom., M.Cs.', role: 'Dosen Tetap', nidn: 'NIDN 0903099108', exp: 'Database Systems' },
  ],

  kurikulum: [
    { kode: 'TRPL101', mk: 'Dasar Pemrograman', sks: 4, sem: 'Semester 1', type: 'Wajib' },
    { kode: 'TRPL102', mk: 'Matematika Diskrit', sks: 3, sem: 'Semester 1', type: 'Wajib' },
    { kode: 'TRPL103', mk: 'Pengantar Teknologi Informasi', sks: 2, sem: 'Semester 1', type: 'Wajib' },
    { kode: 'TRPL201', mk: 'Struktur Data & Algoritma', sks: 4, sem: 'Semester 2', type: 'Wajib' },
    { kode: 'TRPL202', mk: 'Basis Data', sks: 3, sem: 'Semester 2', type: 'Wajib' },
    { kode: 'TRPL301', mk: 'Rekayasa Perangkat Lunak', sks: 4, sem: 'Semester 3', type: 'Wajib' },
    { kode: 'TRPL302', mk: 'Pemrograman Web Lanjut', sks: 3, sem: 'Semester 3', type: 'Wajib' },
    { kode: 'TRPL401', mk: 'Mobile Application Development', sks: 4, sem: 'Semester 4', type: 'Wajib' },
    { kode: 'TRPL402', mk: 'DevOps & Cloud Engineering', sks: 3, sem: 'Semester 4', type: 'Pilihan' },
    { kode: 'TRPL501', mk: 'Health Technopreneurship', sks: 3, sem: 'Semester 5', type: 'Khas' },
    { kode: 'TRPL502', mk: 'Artificial Intelligence Applied', sks: 4, sem: 'Semester 5', type: 'Pilihan' },
    { kode: 'TRPL601', mk: 'Capstone Project I', sks: 6, sem: 'Semester 6', type: 'Wajib' },
  ],

  prestasi: [
    { tier: 'gold', medal: '1', title: 'Juara 1 Hackathon Kesehatan Digital', event: 'Kemenkes RI — Health Innovation Challenge 2025', tahun: '2025', tingkat: 'Nasional' },
    { tier: 'silver', medal: '2', title: 'Juara 2 Gemastik UI/UX Competition', event: 'Pagelaran Mahasiswa Nasional Bidang TIK', tahun: '2025', tingkat: 'Nasional' },
    { tier: 'gold', medal: '1', title: 'Best Paper — ICITACEE Conference', event: 'International Conf. on ICT & Electronics', tahun: '2024', tingkat: 'Internasional' },
    { tier: 'bronze', medal: '3', title: 'Juara 3 Lomba Capture The Flag', event: 'BSSN Cyber Jawara 2024', tahun: '2024', tingkat: 'Nasional' },
    { tier: 'gold', medal: '1', title: 'Juara 1 App Development Challenge', event: 'ASEAN Student Innovation Summit', tahun: '2024', tingkat: 'Internasional' },
    { tier: 'silver', medal: '2', title: 'Finalis Kompetisi Startup Digital', event: 'Kemenparekraf BEKRAF Challenge', tahun: '2024', tingkat: 'Nasional' },
  ],

  fasilitas: [
    { name: 'Lab Pemrograman', desc: 'Lab khusus pemrograman dengan 40 workstation iMac & PC, dilengkapi IDE profesional dan akses GPU untuk ML.', meta: ['40 workstation', 'Gedung B — lt. 2'], tag: 'LAB/PROG' },
    { name: 'Lab Jaringan Komputer', desc: 'Lab simulasi jaringan dengan Cisco rack, perangkat switch/router enterprise, dan sandbox untuk eksperimen keamanan.', meta: ['25 seat', 'Gedung B — lt. 3'], tag: 'LAB/NET' },
    { name: 'Ruang Kelas Modern', desc: 'Ruang kelas ber-AC dengan smart projector, whiteboard digital, dan mic lavalier untuk kuliah hybrid.', meta: ['8 ruang', 'Gedung A & B'], tag: 'CLASSROOM' },
    { name: 'Perpustakaan Digital', desc: 'Koleksi buku teks & e-book terbaru bidang RPL, akses gratis IEEE Xplore, ACM, dan jurnal Scopus.', meta: ['12k koleksi', 'Gedung A — lt. 1'], tag: 'LIBRARY' },
    { name: 'Coding Learn Center', desc: 'Ruang kolaboratif 24/7 untuk mahasiswa berdiskusi, mengerjakan proyek, dan mengikuti bootcamp internal.', meta: ['Open 24/7', 'Gedung C — lt. 1'], tag: 'COWORK' },
    { name: 'Innovation Lab', desc: 'Fasilitas untuk prototyping produk digital — IoT kit, Raspberry Pi, printer 3D, dan VR headset.', meta: ['Prototyping', 'Gedung C — lt. 2'], tag: 'LAB/INNO' },
  ],
};

window.NAV = [
  { key: 'home', label: 'Beranda' },
  { key: 'tentang', label: 'Tentang Prodi', children: ['Profil Program Studi', 'Visi Misi', 'Profil Lulusan', 'Struktur Organisasi'] },
  { key: 'kurikulum', label: 'Kurikulum', children: ['Matakuliah', 'RPS', 'Jadwal Kuliah'] },
  { key: 'dosen', label: 'Dosen' },
  { key: 'fasilitas', label: 'Fasilitas', children: ['Lab Pemrograman', 'Lab Jaringan', 'Ruang Kelas', 'Perpustakaan', 'Coding Learn'] },
  { key: 'prestasi', label: 'Prestasi' },
  { key: 'hmps', label: 'HMPS', children: ['Profil HMPS', 'Struktur Organisasi', 'Program Kerja', 'Kegiatan'] },
];
