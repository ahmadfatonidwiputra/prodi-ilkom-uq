/* global React */

// ============ KURIKULUM ============
function KurikulumPage() {
  const [tab, setTab] = React.useState('Semua');
  const semesters = ['Semua', 'Semester 1', 'Semester 2', 'Semester 3', 'Semester 4', 'Semester 5', 'Semester 6'];
  const rows = tab === 'Semua' ? window.DATA.kurikulum : window.DATA.kurikulum.filter(r => r.sem === tab);
  const totalSks = rows.reduce((a, b) => a + b.sks, 0);

  return (
    <section className="section" style={{ paddingTop: 48 }}>
      <div className="container">
        <div className="section-head">
          <span className="eyebrow">Kurikulum</span>
          <h2>Matakuliah <span className="serif">Program Studi</span></h2>
          <p>144 SKS tersebar dalam 8 semester — memadukan fondasi CS, rekayasa perangkat lunak terapan, dan spesialisasi health technopreneurship.</p>
        </div>

        <div className="grid g-4" style={{ marginBottom: 32 }}>
          {[
            { num: '144', label: 'Total SKS' },
            { num: '8', label: 'Semester' },
            { num: '60%', label: 'Praktikum' },
            { num: '6', label: 'SKS Capstone' },
          ].map((s) => (
            <div className="card" key={s.label} style={{ padding: 20 }}>
              <div style={{ fontSize: 30, fontWeight: 700, letterSpacing: '-0.03em' }}>{s.num}</div>
              <div style={{ fontSize: 12.5, color: 'var(--ink-mute)', marginTop: 4 }}>{s.label}</div>
            </div>
          ))}
        </div>

        <div className="flex gap-2" style={{ marginBottom: 16, flexWrap: 'wrap' }}>
          {semesters.map((s) => (
            <button
              key={s}
              className="btn-ghost"
              onClick={() => setTab(s)}
              style={tab === s ? { borderColor: 'var(--purple-500)', color: 'var(--purple-700)', background: 'var(--purple-50)' } : {}}
            >
              {s}
            </button>
          ))}
          <div style={{ marginLeft: 'auto', fontSize: 13, color: 'var(--ink-mute)', alignSelf: 'center' }}>
            Menampilkan <strong style={{ color: 'var(--ink)' }}>{rows.length}</strong> mata kuliah · <strong style={{ color: 'var(--ink)' }}>{totalSks}</strong> SKS
          </div>
        </div>

        <div className="kurikulum-wrap">
          <div className="kurikulum-head">
            <span>Kode</span>
            <span>Mata Kuliah</span>
            <span>SKS</span>
            <span>Semester</span>
            <span>Tipe</span>
          </div>
          {rows.map((r) => (
            <div className="kurikulum-row" key={r.kode}>
              <span className="kode">{r.kode}</span>
              <span className="mk-name">{r.mk}</span>
              <span><span className="sks-pill">{r.sks} SKS</span></span>
              <span className="sem">{r.sem}</span>
              <span className="type">{r.type}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ============ FASILITAS ============
function FasilitasPage() {
  return (
    <section className="section" style={{ paddingTop: 48 }}>
      <div className="container">
        <div className="section-head">
          <span className="eyebrow">Fasilitas</span>
          <h2>Fasilitas <span className="serif">untuk belajar</span> dan berkarya.</h2>
          <p>Laboratorium dengan perangkat industri, ruang kolaborasi 24/7, dan akses jurnal internasional — semua dalam satu kampus.</p>
        </div>
        <div className="grid g-3">
          {window.DATA.fasilitas.map((f) => (
            <div className="fasilitas-card" key={f.name}>
              <div className="fasilitas-image">
                <div className="tile-pattern" />
                <div className="label">{f.tag}</div>
              </div>
              <div className="fasilitas-body">
                <h4>{f.name}</h4>
                <p>{f.desc}</p>
                <div className="meta">
                  {f.meta.map((m, i) => <span key={i}>· {m}</span>)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ============ PRESTASI ============
function PrestasiPage() {
  return (
    <section className="section" style={{ paddingTop: 48 }}>
      <div className="container">
        <div className="section-head">
          <span className="eyebrow">Prestasi Mahasiswa</span>
          <h2>Prestasi <span className="serif">mahasiswa</span> D4 TRPL.</h2>
          <p>Kompetisi, publikasi, dan kontribusi mahasiswa di kancah nasional & internasional.</p>
        </div>

        <div className="grid g-3">
          {window.DATA.prestasi.map((p, i) => (
            <div className="prestasi-card" key={i}>
              <div className={`prestasi-medal ${p.tier === 'silver' ? 'silver' : p.tier === 'bronze' ? 'bronze' : ''}`}>
                {p.medal}
              </div>
              <h4>{p.title}</h4>
              <p className="event">{p.event}</p>
              <div className="meta">
                <span>📅 {p.tahun}</span>
                <span>· {p.tingkat}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ============ PENDAFTARAN ============
function PendaftaranPage() {
  const [submitted, setSubmitted] = React.useState(false);
  const [form, setForm] = React.useState({ nama: '', email: '', phone: '', asal: '', jurusan: '', alasan: '' });

  const handle = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const submit = (e) => { e.preventDefault(); setSubmitted(true); };

  if (submitted) {
    return (
      <section className="section" style={{ paddingTop: 80 }}>
        <div className="container" style={{ maxWidth: 640, textAlign: 'center' }}>
          <div style={{ width: 72, height: 72, margin: '0 auto 24px', borderRadius: 20, background: 'var(--purple-50)', color: 'var(--purple-700)', display: 'grid', placeItems: 'center', fontSize: 32 }}>✓</div>
          <h2 style={{ fontSize: 36, marginBottom: 14 }}>Terima kasih, <span className="serif">{form.nama || 'calon mahasiswa'}!</span></h2>
          <p style={{ color: 'var(--ink-soft)', fontSize: 16, marginBottom: 28 }}>
            Pendaftaranmu sudah kami terima. Tim admisi akan menghubungi <strong>{form.email || 'emailmu'}</strong> dalam 2×24 jam kerja dengan instruksi selanjutnya.
          </p>
          <button className="btn-primary-lg" onClick={() => setSubmitted(false)}>Daftar lagi</button>
        </div>
      </section>
    );
  }

  return (
    <section className="section" style={{ paddingTop: 48 }}>
      <div className="container">
        <div className="pendaftaran-grid">
          <div>
            <span className="eyebrow">Pendaftaran 2026</span>
            <h2 style={{ fontSize: 'clamp(30px, 4vw, 44px)', lineHeight: 1.08, margin: '14px 0 18px' }}>
              Mulai <span className="serif">perjalananmu</span> di D4 TRPL.
            </h2>
            <p style={{ color: 'var(--ink-soft)', fontSize: 16, lineHeight: 1.65, marginBottom: 28 }}>
              Isi formulir singkat di samping. Tim admisi akan mengirim informasi lengkap — biaya, jalur seleksi, dan timeline — langsung ke emailmu.
            </p>

            <div className="card" style={{ padding: 24, background: 'var(--purple-50)', border: '1px solid var(--purple-200)' }}>
              <h4 style={{ fontSize: 14, fontWeight: 700, marginBottom: 14, letterSpacing: '0.05em', textTransform: 'uppercase', color: 'var(--purple-700)' }}>Timeline</h4>
              {[
                ['Gel. 1', '1 Feb — 31 Mar 2026'],
                ['Gel. 2', '1 Apr — 31 Mei 2026'],
                ['Gel. 3', '1 Jun — 15 Jul 2026'],
                ['Awal kuliah', '8 September 2026'],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between" style={{ padding: '8px 0', borderBottom: '1px solid var(--purple-200)', fontSize: 13.5 }}>
                  <strong style={{ color: 'var(--purple-700)' }}>{k}</strong>
                  <span style={{ color: 'var(--ink-soft)' }}>{v}</span>
                </div>
              ))}
            </div>
          </div>

          <form className="card card-pad-lg" onSubmit={submit}>
            <div className="form-grid">
              <div className="field" style={{ gridColumn: 'span 2' }}>
                <label>Nama lengkap</label>
                <input required value={form.nama} onChange={handle('nama')} placeholder="Sesuai ijazah / rapor" />
              </div>
              <div className="field">
                <label>Email</label>
                <input required type="email" value={form.email} onChange={handle('email')} placeholder="kamu@email.com" />
              </div>
              <div className="field">
                <label>Nomor WhatsApp</label>
                <input required value={form.phone} onChange={handle('phone')} placeholder="+62 8xx" />
              </div>
              <div className="field">
                <label>Asal sekolah</label>
                <input required value={form.asal} onChange={handle('asal')} placeholder="SMA/SMK asal" />
              </div>
              <div className="field">
                <label>Jurusan SMA/SMK</label>
                <select required value={form.jurusan} onChange={handle('jurusan')}>
                  <option value="">Pilih jurusan</option>
                  <option>IPA</option>
                  <option>IPS</option>
                  <option>Bahasa</option>
                  <option>SMK RPL / TKJ</option>
                  <option>SMK lainnya</option>
                </select>
              </div>
              <div className="field" style={{ gridColumn: 'span 2' }}>
                <label>Kenapa kamu tertarik dengan TRPL?</label>
                <textarea rows={4} value={form.alasan} onChange={handle('alasan')} placeholder="Ceritakan singkat — ini membantu kami mengenalmu (opsional)" />
                <span className="hint">Maksimal 500 karakter</span>
              </div>
            </div>

            <div className="flex gap-3" style={{ marginTop: 24, alignItems: 'center' }}>
              <button type="submit" className="btn-primary-lg">
                Kirim Pendaftaran <span>→</span>
              </button>
              <span style={{ fontSize: 12.5, color: 'var(--ink-mute)' }}>Kami tidak membagikan data ke pihak ketiga.</span>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}

// ============ TENTANG (simple) ============
function TentangPage() {
  return (
    <section className="section" style={{ paddingTop: 48 }}>
      <div className="container">
        <div className="section-head">
          <span className="eyebrow">Tentang Program Studi</span>
          <h2>Profil <span className="serif">D4 TRPL</span> UNBIM</h2>
          <p>Program Studi D4 Teknologi Rekayasa Perangkat Lunak adalah program sarjana terapan 4 tahun (144 SKS) di bawah Fakultas Teknik Universitas Bima Internasional.</p>
        </div>

        <div className="grid g-2" style={{ alignItems: 'start', gap: 32 }}>
          <div className="card card-pad-lg">
            <span className="eyebrow">Visi</span>
            <p style={{ fontSize: 20, lineHeight: 1.45, margin: '16px 0 0', color: 'var(--ink)', letterSpacing: '-0.015em' }}>
              <span className="serif">Menjadi program studi</span> Teknologi Rekayasa Perangkat Lunak
              yang unggul, inovatif, dan berdaya saing global dalam menghasilkan
              pengembang perangkat lunak dan teknologi kesehatan berbasis
              <em> health technopreneurship</em>.
            </p>
          </div>
          <div className="card card-pad-lg">
            <span className="eyebrow">Misi</span>
            <ol style={{ margin: '16px 0 0', padding: 0, listStyle: 'none', display: 'grid', gap: 14 }}>
              {[
                'Menyelenggarakan pendidikan vokasi bidang RPL berorientasi industri.',
                'Melaksanakan penelitian terapan bidang teknologi kesehatan.',
                'Menyelenggarakan pengabdian masyarakat berbasis teknologi digital.',
                'Membangun kemitraan strategis dengan industri dan instansi kesehatan.',
              ].map((m, i) => (
                <li key={i} style={{ display: 'flex', gap: 14, fontSize: 14.5, color: 'var(--ink-soft)', lineHeight: 1.6 }}>
                  <span className="mono" style={{ color: 'var(--purple-500)', fontSize: 11, paddingTop: 3 }}>0{i + 1}</span>
                  {m}
                </li>
              ))}
            </ol>
          </div>
        </div>

        <div className="section-head" style={{ marginTop: 64 }}>
          <span className="eyebrow">Profil Lulusan</span>
          <h2 style={{ fontSize: 32 }}>Karir <span className="serif">yang dapat ditempuh</span> lulusan.</h2>
        </div>
        <div className="grid g-3">
          {[
            ['Software Engineer', 'Merancang & mengembangkan sistem perangkat lunak skala enterprise.'],
            ['Full-Stack Developer', 'Mengembangkan aplikasi web/mobile dari backend hingga frontend.'],
            ['Health-Tech Specialist', 'Mendesain solusi digital untuk rumah sakit, klinik, dan layanan kesehatan.'],
            ['DevOps & Cloud Engineer', 'Mengelola infrastruktur cloud dan pipeline CI/CD.'],
            ['Data Engineer', 'Membangun data pipeline dan sistem analitik.'],
            ['Technopreneur', 'Membangun startup berbasis produk digital.'],
          ].map(([t, d]) => (
            <div className="card" key={t}>
              <h4 style={{ fontSize: 17, fontWeight: 600, marginBottom: 8, letterSpacing: '-0.015em' }}>{t}</h4>
              <p style={{ fontSize: 13.5, color: 'var(--ink-soft)', lineHeight: 1.6 }}>{d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function HmpsPage() {
  return <TentangPage />;
}

window.KurikulumPage = KurikulumPage;
window.FasilitasPage = FasilitasPage;
window.PrestasiPage = PrestasiPage;
window.PendaftaranPage = PendaftaranPage;
window.TentangPage = TentangPage;
window.HmpsPage = HmpsPage;
