/* global React, ReactDOM */

const TWEAKS = /*EDITMODE-BEGIN*/{
  "variant": "minimal"
}/*EDITMODE-END*/;

function App() {
  const [page, setPage] = React.useState(() => localStorage.getItem('trpl-page') || 'home');
  const [variant, setVariant] = React.useState(() => localStorage.getItem('trpl-variant') || TWEAKS.variant);
  const [tweaksOpen, setTweaksOpen] = React.useState(false);

  React.useEffect(() => { localStorage.setItem('trpl-page', page); window.scrollTo(0, 0); }, [page]);
  React.useEffect(() => {
    localStorage.setItem('trpl-variant', variant);
    document.body.setAttribute('data-variant', variant);
  }, [variant]);

  // Tweaks host handshake
  React.useEffect(() => {
    const onMsg = (e) => {
      if (e.data?.type === '__activate_edit_mode') setTweaksOpen(true);
      if (e.data?.type === '__deactivate_edit_mode') setTweaksOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  const setV = (v) => {
    setVariant(v);
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { variant: v } }, '*');
  };

  const renderPage = () => {
    switch (page) {
      case 'home': return <window.HomePage setPage={setPage} />;
      case 'dosen': return <window.DosenPage />;
      case 'kurikulum': return <window.KurikulumPage />;
      case 'fasilitas': return <window.FasilitasPage />;
      case 'prestasi': return <window.PrestasiPage />;
      case 'pendaftaran': return <window.PendaftaranPage />;
      case 'tentang': return <window.TentangPage />;
      case 'hmps': return <window.HmpsPage />;
      default: return <window.HomePage setPage={setPage} />;
    }
  };

  return (
    <div className="shell" data-screen-label={page}>
      <window.Topbar page={page} setPage={setPage} />
      <main style={{ flex: 1 }}>{renderPage()}</main>
      <window.Footer />

      <div className={`tweaks ${tweaksOpen ? 'open' : ''}`}>
        <h4>Tweaks</h4>
        <div className="group">
          <div className="group-label">Gaya visual</div>
          <div className="seg">
            {[
              ['minimal', 'Minimal'],
              ['gradient', 'Gradient'],
              ['editorial', 'Editorial'],
            ].map(([v, l]) => (
              <button key={v} className={variant === v ? 'on' : ''} onClick={() => setV(v)}>{l}</button>
            ))}
          </div>
        </div>
        <div className="group">
          <div className="group-label">Halaman aktif</div>
          <div className="seg" style={{ flexWrap: 'wrap' }}>
            {['home', 'dosen', 'kurikulum', 'fasilitas', 'prestasi', 'pendaftaran', 'tentang'].map((p) => (
              <button key={p} className={page === p ? 'on' : ''} onClick={() => setPage(p)} style={{ flex: '0 1 auto', fontSize: 11 }}>{p}</button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
