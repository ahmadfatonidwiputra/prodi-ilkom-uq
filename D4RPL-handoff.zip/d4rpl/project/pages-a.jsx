/* global React */

// ============ HOME ============
function HomePage({ setPage }) {
  return (
    <>
      <section className="hero">
        <div className="hero-bg" />
        <div className="container hero-content">
          <div className="tag" style={{ marginBottom: 24 }}>
            <span className="dot" /> Akreditasi Unggul · Pendaftaran 2026 dibuka
          </div>
          <h1>
            Bangun perangkat lunak <span className="accent serif">yang berarti</span>,
            di prodi berorientasi industri.
          </h1>
          <p className="lede">
            Program Studi D4 Teknologi Rekayasa Perangkat Lunak UNBIM — kurikulum
            terapan berfokus pada <em>health technopreneurship</em>, rekayasa
            perangkat lunak modern, dan pengembangan produk digital siap pakai.
          </p>
          <div className="hero-actions">
            <button className="btn-primary-lg" onClick={() => setPage('pendaftaran')}>
              Daftar Sekarang <span>→</span>
            </button>
            <button className="btn-ghost-lg" onClick={() => setPage('tentang')}>
              Pelajari Program
            </button>
          </div>
        </div>
      </section>

      <section className="container" style={{ marginTop: -20 }}>
        <div className="stats-row">
          {window.DATA.stats.map((s) => (
            <div className="stat-cell" key={s.label}>
              <div className="num">{s.num}<span className="plus">{s.plus}</span></div>
              <div className="label">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="grid g-3" style={{ alignItems: 'stretch', gap: 24 }}>
            <div className="card card-pad-lg" style={{ gridColumn: 'span 2' }}>
              <span className="eyebrow">Profil Program Studi</span>
              <h2 style={{ fontSize: 34, margin: '14px 0 18px' }}>
                <span className="serif">Menjadi program studi</span> unggul dan
                inovatif di bidang teknologi rekayasa perangkat lunak.
              </h2>
              <p style={{ color: 'var(--ink-soft)', fontSize: 15.5, lineHeight: 1.65, marginBottom: 24 }}>
                D4 TRPL UNBIM mempersiapkan lulusan siap kerja sebagai
                software engineer, full-stack developer, dan product specialist —
                dengan fokus khusus pada solusi teknologi kesehatan yang relevan
                dengan kebutuhan industri di Indonesia Timur.
              </p>
              <div className="flex gap-3">
                <button className="btn-ghost" onClick={() => setPage('tentang')}>Profil lengkap →</button>
                <button className="btn-ghost" onClick={() => setPage('kurikulum')}>Kurikulum →</button>
              </div>
            </div>

            <div className="card card-pad-lg" style={{ background: 'var(--purple-900)', color: '#fff', border: 'none' }}>
              <span className="eyebrow" style={{ color: 'var(--purple-300)' }}>Keunggulan</span>
              <h3 style={{ fontSize: 22, margin: '14px 0 20px', color: '#fff' }}>
                Kenapa memilih D4 TRPL?
              </h3>
              <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: 14 }}>
                {[
                  'Kurikulum 60% praktik, 40% teori',
                  'Sertifikasi industri (AWS, Alibaba Cloud)',
                  'Magang di startup & RS partner',
                  'Health-tech as a specialty track',
                ].map((t, i) => (
                  <li key={i} style={{ display: 'flex', gap: 12, fontSize: 14, color: '#efe4ff' }}>
                    <span className="mono" style={{ color: 'var(--purple-300)', fontSize: 11, paddingTop: 2 }}>
                      0{i + 1}
                    </span>
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="section" style={{ paddingTop: 24 }}>
        <div className="container">
          <div className="flex justify-between items-center" style={{ marginBottom: 28 }}>
            <div>
              <span className="eyebrow">Fasilitas unggulan</span>
              <h2 style={{ fontSize: 32, marginTop: 10 }}>
                Ruang untuk <span className="serif">belajar, bereksperimen, dan membangun.</span>
              </h2>
            </div>
            <button className="btn-ghost" onClick={() => setPage('fasilitas')}>Lihat semua →</button>
          </div>
          <div className="grid g-3">
            {window.DATA.fasilitas.slice(0, 3).map((f) => (
              <div className="fasilitas-card" key={f.name}>
                <div className="fasilitas-image">
                  <div className="tile-pattern" />
                  <div className="label">{f.tag}</div>
                </div>
                <div className="fasilitas-body">
                  <h4>{f.name}</h4>
                  <p>{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" style={{ paddingTop: 24 }}>
        <div className="container">
          <div className="flex justify-between items-center" style={{ marginBottom: 28 }}>
            <div>
              <span className="eyebrow">Dosen unggulan</span>
              <h2 style={{ fontSize: 32, marginTop: 10 }}>
                Diajar <span className="serif">praktisi & peneliti</span> aktif.
              </h2>
            </div>
            <button className="btn-ghost" onClick={() => setPage('dosen')}>Semua dosen →</button>
          </div>
          <div className="grid g-4">
            {window.DATA.dosen.slice(0, 4).map((d, i) => (
              <DosenCard key={i} d={d} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

function DosenCard({ d }) {
  return (
    <div className="dosen-card">
      <div className="dosen-photo">
        <div className="dosen-avatar" />
        <div className="mono-label">FOTO/DOSEN</div>
      </div>
      <div className="dosen-body">
        <div className="name">{d.name}</div>
        <div className="role">{d.role}</div>
        <div className="nidn">{d.nidn}</div>
      </div>
    </div>
  );
}

// ============ DOSEN ============
function DosenPage() {
  const [filter, setFilter] = React.useState('Semua');
  const filters = ['Semua', 'Ketua Prodi', 'Dosen Tetap'];
  return (
    <section className="section" style={{ paddingTop: 48 }}>
      <div className="container">
        <div className="section-head">
          <span className="eyebrow">Tim pengajar</span>
          <h2>Dosen <span className="serif">Program Studi</span> D4 TRPL</h2>
          <p>Tim pengajar dengan latar akademik & pengalaman industri yang beragam — dari software engineering hingga cyber security.</p>
        </div>

        <div className="flex gap-2" style={{ marginBottom: 28, flexWrap: 'wrap' }}>
          {filters.map((f) => (
            <button
              key={f}
              className="btn-ghost"
              onClick={() => setFilter(f)}
              style={filter === f ? { borderColor: 'var(--purple-500)', color: 'var(--purple-700)', background: 'var(--purple-50)' } : {}}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="grid g-4">
          {window.DATA.dosen.map((d, i) => (
            <DosenCard key={i} d={d} />
          ))}
        </div>
      </div>
    </section>
  );
}

window.HomePage = HomePage;
window.DosenPage = DosenPage;
window.DosenCard = DosenCard;
