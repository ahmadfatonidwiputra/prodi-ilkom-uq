/* global React */

function Topbar({ page, setPage }) {
  return (
    <div className="topbar">
      <div className="container topbar-inner">
        <div className="brand" onClick={() => setPage('home')}>
          <div className="brand-mark">
            <img src="assets/unbim-icon.png" alt="" />
          </div>
          <div className="brand-text">
            <span className="name">UNBIM · D4 TRPL</span>
            <span className="sub">Teknologi Rekayasa Perangkat Lunak</span>
          </div>
        </div>

        <nav className="nav">
          {window.NAV.map((item) => {
            const active = page === item.key;
            if (item.children) {
              return (
                <div key={item.key} className="dropdown">
                  <span
                    className={`nav-item ${active ? 'active' : ''}`}
                    onClick={() => setPage(item.key)}
                  >
                    {item.label}
                    <span className="caret">▾</span>
                  </span>
                  <div className="dropdown-menu">
                    {item.children.map((c) => (
                      <a key={c} onClick={() => setPage(item.key)}>
                        {c}
                      </a>
                    ))}
                  </div>
                </div>
              );
            }
            return (
              <span
                key={item.key}
                className={`nav-item ${active ? 'active' : ''}`}
                onClick={() => setPage(item.key)}
              >
                {item.label}
              </span>
            );
          })}
          <button className="btn-cta pill" onClick={() => setPage('pendaftaran')}>
            Pendaftaran <span>→</span>
          </button>
        </nav>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="grid g-4" style={{ gap: 40 }}>
          <div style={{ gridColumn: 'span 2' }}>
            <div className="name-lg">D4 Teknologi Rekayasa Perangkat Lunak</div>
            <p style={{ fontSize: 13.5, lineHeight: 1.65, opacity: 0.8, maxWidth: '42ch' }}>
              Universitas Bima Internasional. Menyiapkan pengembang perangkat lunak
              dengan fokus health technopreneurship.
            </p>
            <p style={{ fontSize: 12.5, opacity: 0.7, marginTop: 18, lineHeight: 1.65 }}>
              Jl. Medika Farma Husada, Batu Ringgit, Sekarbela,<br />
              Kota Mataram, Nusa Tenggara Barat
            </p>
          </div>
          <div>
            <h6>Program</h6>
            <a>Profil Prodi</a>
            <a>Visi &amp; Misi</a>
            <a>Kurikulum</a>
            <a>Dosen</a>
          </div>
          <div>
            <h6>Mahasiswa</h6>
            <a>Fasilitas</a>
            <a>Prestasi</a>
            <a>HMPS</a>
            <a>Pendaftaran</a>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 Program Studi D4 TRPL · Universitas Bima Internasional</span>
          <span className="mono">d4trpl.unbim.ac.id</span>
        </div>
      </div>
    </footer>
  );
}

window.Topbar = Topbar;
window.Footer = Footer;
